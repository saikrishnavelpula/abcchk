'use strict'
angular.module("britishGas",["ngRoute"]);