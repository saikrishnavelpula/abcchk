'use strict'
angular.module("britishGas")
	   .config(businessConfig);
function businessConfig($routeProvider){
	$routeProvider
	.when("/",{
		templateUrl :'app/Business/Business.html'
	})
	.when("/Business_gas",{
		templateUrl :'app/BusinessGas/BusinessGas.html'
	})
	.when("/Business_electricity",{
		templateUrl :'app/BusinessElectricity/BusinessElectricity.html'
	})
	.otherwise({
        redirect: '/'
    });
}
